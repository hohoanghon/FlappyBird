
package flappybird;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import pkg2dgamesframework.AFrameOnImage;
import pkg2dgamesframework.Animation;
import pkg2dgamesframework.GameScreen;


public class Flappybird extends GameScreen {
    private Animation bird_anim;
    private BufferedImage birds ;

    
    public static float g = 0.2f;
    
    private Bird bird;
    private Ground ground;
    private BackGround bg;
    private Chimneys chimneys;
    private point Point;
    
    private int BEGIN_SCREEN = 0;
    private int GAMEPLAY_SCREEN = 1;
    private int GAMEOVER_SCREEN = 2;
    private int CurrentScreen = BEGIN_SCREEN;
    
    private int temp = 0;
    
    public Flappybird(){
        super(805,600);
        
        try {    
            birds = ImageIO.read(new File("Assets/bird_sprite.png"));
            
        } catch (IOException ex) {
            Logger.getLogger(Flappybird.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        bird_anim = new Animation(80);
        AFrameOnImage f;
        f = new AFrameOnImage(0,0,60,60);
        bird_anim.AddFrame(f);
        f = new AFrameOnImage(60,0,60,60);
        bird_anim.AddFrame(f);
        f = new AFrameOnImage(120,0,60,60);
        bird_anim.AddFrame(f);
        f = new AFrameOnImage(60,0,60,60);
        bird_anim.AddFrame(f);
        bird = new Bird(350, 250, 50, 50);
        ground = new Ground();
        bg = new BackGround();
        chimneys = new Chimneys();
        Point = new point();
        
        BeginGame();
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        new Flappybird();
    }

    private void resetGame(){
        bird.setPos(350, 250);
        bird.setVt(0);
        bird.setLive(true);
        Point.setPoint(0);
        bird.setIsFlying(false);
        ground.resetTd();
    }
    
    @Override
    public void GAME_UPDATE(long deltaTime) {
        
        if(CurrentScreen == BEGIN_SCREEN){
        
            resetGame();
            chimneys.resetChimneys();
        }else if(CurrentScreen == GAMEPLAY_SCREEN){
            
            
            if(bird.getLive()) bird_anim.Update_Me(deltaTime);
            bird.update(deltaTime);
            ground.Update();
            
            chimneys.update();
            
            for(int i = 0; i<Chimneys.SIZE;i++){
                if(bird.getRect().intersects(chimneys.getChimney(i).getRect())){
                    if(bird.getLive()) bird.bupSound.play();
                    bird.setLive(false);
                    
                }      
            }
            for(int i = 0; i<Chimneys.SIZE; i++){
                if(i%2==0 && bird.getPosX() > chimneys.getChimney(i).getPosX() && !chimneys.getChimney(i).getIsBehindBird()){
                   Point.setPoint(Point.getPoint()+1);  
                   temp = Point.getPoint();
                   if(temp % 15 == 0 ){
                        bg.Update();
                   }
                   chimneys.getDiem(temp);
                   ground.setTd(temp);
                   
                   bird.getMoneySound.play();
                   chimneys.getChimney(i).setIsBehindBird(true);
                }
            }
            
            if(bird.getPosY() + bird.getH() > ground.getYGround()|| bird.getPosY() < 0 ) 
            { CurrentScreen = GAMEOVER_SCREEN;
                if(bird.getLive()) bird.bupSound.play();
            }
                
            
        }else {
        
        }
        
        
    }

    @Override
    public void GAME_PAINT(Graphics2D g2) {
        
//        g2.setColor(Color.decode("#b8daef"));
//        g2.fillRect(0, 0, MASTER_WIDTH, MASTER_HEIGHT);
        bg.Paint(g2);
        chimneys.paint(g2);
        
        ground.Paint(g2);
        
       
        
        if(bird.getIsFlying()){
            bird_anim.PaintAnims((int) bird.getPosX(),(int) bird.getPosY(),birds,g2,0,-0.75f);
            }
        else{
            bird_anim.PaintAnims((int) bird.getPosX(),(int) bird.getPosY(),birds,g2,0,0);
        }
        
        if(CurrentScreen == BEGIN_SCREEN){
            g2.setColor(Color.black);
            g2.drawString("PRESS SPACE TO PLAY GAME!", 300, 350);
            //bird_anim.PaintAnims((int) bird.getPosX(),(int) bird.getPosY(),birds,g2,0,0);
        }
        if(CurrentScreen == GAMEOVER_SCREEN){
            g2.setColor(Color.red);
            g2.drawString("PRESS SPACE TO TURN BACK BEGIN SCREEN!", 300, 350);
            g2.setColor(Color.red);
            g2.drawString("YOUR POINT: "+Point.getPoint(), 390, 390);
          
        }
        
        g2.setColor(Color.blue);
        g2.drawString("POINT: "+Point.getPoint(), 20, 40);
        
        if((Point.getPoint()%10) == 0 || (Point.getPoint()%10) == 1 || (Point.getPoint()%10) == 2){
            g2.setColor(Color.blue);
            g2.drawString("LEVEL : "+((Point.getPoint()/10)+1), 100, 40);
        }
    }

    @Override
    public void KEY_ACTION(KeyEvent e, int Event) {

        if(Event == KEY_PRESSED) {
            
            if(CurrentScreen == BEGIN_SCREEN){

                CurrentScreen = GAMEPLAY_SCREEN;
                
            }else if(CurrentScreen == GAMEPLAY_SCREEN){
               if(bird.getLive()) bird.fly();

            }else if(CurrentScreen == GAMEOVER_SCREEN){
                CurrentScreen = BEGIN_SCREEN;
            }
            
        }
        }
}
    

