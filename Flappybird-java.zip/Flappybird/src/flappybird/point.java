/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flappybird;

/**
 *
 * @author LENOVO
 */
public class point {
    private int point = 0;
    public void setPoint(int p){
        point = p;
    }
    public int getPoint(){
        return point;
    }
}
